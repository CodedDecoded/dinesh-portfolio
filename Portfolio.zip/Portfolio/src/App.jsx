import { useLayoutEffect, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import FluidReveal from './components/FluidReveal.jsx'
import {
  capabilities,
  experience,
  principles,
  profile,
  projects,
  stack,
} from './data/portfolio.js'

gsap.registerPlugin(ScrollTrigger)

function Icon({ name }) {
  const paths = {
    arrow: (
      <>
        <path d="M5 12h13M13 6l6 6-6 6" />
      </>
    ),
    external: (
      <>
        <path d="M8 8h8v8" />
        <path d="m8 16 8-8" />
      </>
    ),
    nodes: (
      <>
        <circle cx="6" cy="6" r="2.5" />
        <circle cx="18" cy="7" r="2.5" />
        <circle cx="12" cy="18" r="2.5" />
        <path d="m8.5 6.3 7 .4M7.3 8.2l3.4 7.4m6-6.4-3.4 6.6" />
      </>
    ),
    spark: (
      <>
        <path d="m12 3 1.4 5.1L18 6l-2.1 4.6L21 12l-5.1 1.4L18 18l-4.6-2.1L12 21l-1.4-5.1L6 18l2.1-4.6L3 12l5.1-1.4L6 6l4.6 2.1L12 3Z" />
      </>
    ),
    blocks: (
      <>
        <rect x="3" y="4" width="8" height="7" rx="2" />
        <rect x="13" y="4" width="8" height="7" rx="2" />
        <rect x="3" y="13" width="8" height="7" rx="2" />
        <rect x="13" y="13" width="8" height="7" rx="2" />
      </>
    ),
    people: (
      <>
        <circle cx="8" cy="8" r="3" />
        <circle cx="17" cy="9" r="2.5" />
        <path d="M3.5 19c.4-4 2-6 4.5-6s4.1 2 4.5 6m.5-4.5c1-.9 2.1-1.2 3.3-.9 2 .5 3.1 2.3 3.2 5.4" />
      </>
    ),
    menu: (
      <>
        <path d="M4 8h16M4 16h16" />
      </>
    ),
    close: (
      <>
        <path d="m6 6 12 12M18 6 6 18" />
      </>
    ),
  }

  return (
    <svg className="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      {paths[name]}
    </svg>
  )
}

function ProjectVisual({ type }) {
  if (type === 'marketplace') {
    return (
      <div className="project-ui project-ui--market" aria-hidden="true">
        <div className="ui-topline"><i /><i /><i /><span>JSW ONE</span></div>
        <div className="market-search"><span>Search across the marketplace</span><b>↗</b></div>
        <div className="market-grid">
          <div><span>Orders</span><strong>124</strong><i className="mini-bars" /></div>
          <div><span>Active RFQs</span><strong>38</strong><i className="mini-ring" /></div>
          <div><span>Suppliers</span><strong>92</strong><i className="mini-dots" /></div>
        </div>
        <div className="architecture-strip"><b>Shell</b><span>Search</span><span>Orders</span><span>Insights</span></div>
      </div>
    )
  }

  if (type === 'intelligence') {
    return (
      <div className="project-ui project-ui--intel" aria-hidden="true">
        <div className="ui-topline"><i /><i /><i /><span>FORECAST</span></div>
        <div className="intel-stats"><strong>Revenue intelligence</strong><span>LIVE</span></div>
        <svg className="intel-chart" viewBox="0 0 520 180" preserveAspectRatio="none">
          <defs>
            <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#7567ff" stopOpacity=".46" />
              <stop offset="1" stopColor="#7567ff" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path className="chart-area" d="M0 156C55 147 58 102 105 116s73-42 116-28 61-50 107-35 60-15 94-27 61-5 98-20v174H0Z" />
          <path className="chart-line" d="M0 156C55 147 58 102 105 116s73-42 116-28 61-50 107-35 60-15 94-27 61-5 98-20" />
          <circle cx="328" cy="53" r="8" />
        </svg>
        <div className="intel-tags"><span>Pipeline</span><span>AI agents</span><span>Guidance</span></div>
      </div>
    )
  }

  return (
    <div className="project-ui project-ui--leads" aria-hidden="true">
      <div className="ui-topline"><i /><i /><i /><span>LEADS</span></div>
      <div className="lead-layout">
        <div className="lead-sidebar"><b>Overview</b><span>Inbox</span><span>Pipeline</span><span>Reports</span></div>
        <div className="lead-main">
          <div className="lead-score"><span>Conversion pulse</span><strong>84</strong><i /></div>
          <div className="lead-rows"><i /><i /><i /><i /></div>
        </div>
      </div>
    </div>
  )
}

function App() {
  const appRef = useRef(null)
  const [menuOpen, setMenuOpen] = useState(false)

  useLayoutEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let media
    const context = gsap.context(() => {
      gsap.set('.scroll-progress', { scaleX: 0, transformOrigin: 'left center' })
      gsap.to('.scroll-progress', {
        scaleX: 1,
        ease: 'none',
        scrollTrigger: { start: 0, end: 'max', scrub: 0.25 },
      })

      if (reducedMotion) {
        gsap.set('[data-reveal], .hero-word-inner, .hero-detail', { clearProps: 'all' })
        return
      }

      const intro = gsap.timeline({ defaults: { ease: 'power4.out' }, delay: 0.22 })
      intro
        .from('.hero-eyebrow', { y: 22, autoAlpha: 0, duration: 0.8 })
        .from('.hero-word-inner', { yPercent: 112, duration: 1.15, stagger: 0.09 }, '-=.45')
        .from('.hero-copy', { y: 28, autoAlpha: 0, duration: 0.85 }, '-=.68')
        .from('.hero-actions > *', { y: 20, autoAlpha: 0, duration: 0.65, stagger: 0.08 }, '-=.52')
        .from('.hero-detail', { y: 18, autoAlpha: 0, duration: 0.6, stagger: 0.08 }, '-=.45')

      gsap.utils.toArray('[data-reveal]').forEach((element) => {
        gsap.from(element, {
          y: 54,
          autoAlpha: 0,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: element,
            start: 'top 88%',
            toggleActions: 'play none none reverse',
          },
        })
      })

      gsap.from('.capability-card', {
        y: 80,
        rotate: 2.5,
        autoAlpha: 0,
        stagger: 0.12,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: { trigger: '.capabilities-grid', start: 'top 80%' },
      })

      gsap.from('.connector-path', {
        strokeDashoffset: 1,
        duration: 2,
        stagger: 0.14,
        ease: 'power2.inOut',
        scrollTrigger: { trigger: '.system-map', start: 'top 76%', scrub: 0.7 },
      })

      gsap.utils.toArray('.project-card').forEach((card) => {
        const visual = card.querySelector('.project-visual')
        gsap.from(visual, {
          clipPath: 'inset(0 0 100% 0 round 28px)',
          y: 48,
          duration: 1.25,
          ease: 'power4.inOut',
          scrollTrigger: { trigger: card, start: 'top 78%' },
        })
        gsap.to(visual, {
          yPercent: -7,
          ease: 'none',
          scrollTrigger: { trigger: card, start: 'top bottom', end: 'bottom top', scrub: 1 },
        })
      })

      gsap.from('.experience-line-fill', {
        scaleY: 0,
        transformOrigin: 'top center',
        ease: 'none',
        scrollTrigger: { trigger: '.experience-list', start: 'top 72%', end: 'bottom 74%', scrub: 0.5 },
      })

      gsap.from('.experience-item', {
        x: 50,
        autoAlpha: 0,
        stagger: 0.14,
        duration: 0.85,
        ease: 'power3.out',
        scrollTrigger: { trigger: '.experience-list', start: 'top 74%' },
      })

      gsap.to('.marquee-track', {
        xPercent: -22,
        ease: 'none',
        scrollTrigger: { trigger: '.marquee', start: 'top bottom', end: 'bottom top', scrub: 1 },
      })

      media = gsap.matchMedia()
      media.add('(min-width: 901px) and (min-height: 681px) and (prefers-reduced-motion: no-preference)', () => {
        const section = document.querySelector('.principles')
        const pin = document.querySelector('.principles-pin')
        const cards = gsap.utils.toArray('.principle-card')
        if (!section || !pin || cards.length < 2) return undefined

        gsap.set(cards, {
          zIndex: (index) => index + 1,
          clipPath: (index) => index === 0
            ? 'inset(0% 0 0 0 round 34px)'
            : 'inset(100% 0 0 0 round 34px)',
          scale: 1,
          y: 0,
          rotation: 0,
          filter: 'blur(0px)',
        })

        const timeline = gsap.timeline({
          scrollTrigger: {
            trigger: section,
            start: 'top top',
            end: () => `+=${(cards.length - 1) * Math.max(window.innerHeight * 0.9, 700)}`,
            pin,
            pinSpacing: true,
            scrub: true,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        })

        timeline.to({}, { duration: 0.2 })
        cards.slice(1).forEach((card, index) => {
          const previousCard = cards[index]
          const rotation = index % 2 === 0 ? -1.5 : 1.5
          timeline
            .to(previousCard, {
              scale: 0.94,
              y: -18,
              rotation,
              filter: 'blur(4px)',
              duration: 0.65,
              ease: 'power2.inOut',
            })
            .to(card, {
              clipPath: 'inset(0% 0 0 0 round 34px)',
              duration: 0.65,
              ease: 'power2.inOut',
            }, '<')
            .to({}, { duration: 0.3 })
        })

        return () => {
          timeline.scrollTrigger?.kill()
          timeline.kill()
          gsap.set(cards, { clearProps: 'clipPath,filter,transform,zIndex' })
        }
      })
    }, appRef)

    const handleLayoutReady = () => {
      window.requestAnimationFrame(() => ScrollTrigger.refresh())
    }
    let disposed = false
    document.fonts?.ready.then(() => {
      if (!disposed) handleLayoutReady()
    })
    const refresh = window.setTimeout(() => ScrollTrigger.refresh(), 350)
    const hashScroll = window.setTimeout(() => {
      const targetId = window.location.hash.slice(1)
      if (targetId) document.getElementById(targetId)?.scrollIntoView({ behavior: 'auto' })
    }, 500)
    window.addEventListener('portfolio:layout-ready', handleLayoutReady)
    return () => {
      disposed = true
      window.clearTimeout(refresh)
      window.clearTimeout(hashScroll)
      window.removeEventListener('portfolio:layout-ready', handleLayoutReady)
      media?.revert()
      context.revert()
    }
  }, [])

  const closeMenu = () => setMenuOpen(false)

  return (
    <div ref={appRef} className="app">
      <a className="skip-link" href="#main">Skip to content</a>
      <FluidReveal />
      <div className="scroll-progress" aria-hidden="true" />

      <header className="site-header">
        <a className="brand" href="#top" aria-label="Dinesh Kumar, back to top" onClick={closeMenu}>
          <span className="brand-mark">DK</span>
          <span className="brand-copy">Dinesh Kumar<small>Frontend Architect</small></span>
        </a>
        <nav className={menuOpen ? 'nav nav--open' : 'nav'} aria-label="Primary navigation">
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#work" onClick={closeMenu}>Work</a>
          <a href="#journey" onClick={closeMenu}>Journey</a>
          <a className="nav-cta" href="#contact" onClick={closeMenu}>Say hello <Icon name="arrow" /></a>
        </nav>
        <button
          className="menu-button"
          type="button"
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((current) => !current)}
        >
          <Icon name={menuOpen ? 'close' : 'menu'} />
        </button>
      </header>

      <div className="site-shell">
        <main id="main">
          <section className="hero" id="top">
            <div className="hero-noise" aria-hidden="true" />
            <div className="hero-content">
              <div className="hero-eyebrow">
                <span className="status-dot" />
                Frontend Engineer Architect · New Delhi
              </div>
              <h1 className="hero-title" aria-label="Namaste, I’m Dinesh. I architect joyful frontends.">
                <span className="hero-word"><span className="hero-word-inner">Namaste, I’m</span></span>
                <span className="hero-word"><span className="hero-word-inner hero-word--name">Dinesh.</span></span>
                <span className="hero-word"><span className="hero-word-inner">I architect</span></span>
                <span className="hero-word"><span className="hero-word-inner hero-word--outline">joyful frontends.</span></span>
              </h1>
              <p className="hero-copy">
                I design fast, scalable frontend systems—from micro-frontends and BFFs to rich, real-time product experiences.
              </p>
              <div className="hero-actions">
                <a className="button button--dark" href="#work">
                  Explore my work <Icon name="arrow" />
                </a>
                <a className="text-link" href={profile.linkedin} target="_blank" rel="noreferrer">
                  LinkedIn <Icon name="external" />
                </a>
              </div>
            </div>

            <div className="hero-details" aria-label="Quick profile details">
              <div className="hero-detail">
                <span>Experience</span>
                <strong>{profile.experience}</strong>
              </div>
              <div className="hero-detail">
                <span>Currently</span>
                <strong>{profile.company}</strong>
              </div>
              <div className="hero-detail">
                <span>Approach</span>
                <strong>Code + care</strong>
              </div>
            </div>
            <a className="scroll-cue" href="#about" aria-label="Scroll to about section">
              <span>Scroll to explore</span><i />
            </a>
          </section>

          <div className="marquee" aria-label={`Core technologies: ${stack.join(', ')}`}>
            <div className="marquee-track" aria-hidden="true">
              {[...stack, ...stack].map((item, index) => (
                <span key={`${item}-${index}`}>{item}<i>✦</i></span>
              ))}
            </div>
          </div>

          <section className="section intro-section" id="about">
            <div className="section-label" data-reveal>
              <span>01</span><p>A little context</p>
            </div>
            <div className="intro-copy" data-reveal>
              <p className="overline">Coder · Architect · Mentor</p>
              <h2>From one clean component to an <em>entire platform.</em></h2>
              <div className="intro-body">
                <p>
                  For eight years, I’ve worked where product thinking meets frontend engineering—turning complex requirements into systems that feel clear to users and calm to teams.
                </p>
                <p>
                  My sweet spot is connecting architecture, performance, accessibility and a healthy developer experience into one thoughtful product foundation.
                </p>
              </div>
            </div>

            <div className="system-map" data-reveal aria-label="Frontend architecture system illustration">
              <svg className="system-connectors" viewBox="0 0 800 520" aria-hidden="true">
                <path className="connector-path" pathLength="1" d="M400 260C294 217 220 164 135 106" />
                <path className="connector-path" pathLength="1" d="M400 260C530 205 624 180 704 104" />
                <path className="connector-path" pathLength="1" d="M400 260C278 315 224 386 132 424" />
                <path className="connector-path" pathLength="1" d="M400 260C516 310 607 367 700 422" />
              </svg>
              <div className="system-core"><span>Scalable</span><strong>Frontend<br />system</strong><i /></div>
              <div className="system-node system-node--one"><span>UI</span><strong>Design system</strong></div>
              <div className="system-node system-node--two"><span>DX</span><strong>Team velocity</strong></div>
              <div className="system-node system-node--three"><span>API</span><strong>Clean contracts</strong></div>
              <div className="system-node system-node--four"><span>UX</span><strong>Fast + accessible</strong></div>
            </div>
          </section>

          <section className="section capabilities-section">
            <div className="section-heading" data-reveal>
              <div className="section-label"><span>02</span><p>What I bring</p></div>
              <h2>Big-picture thinking.<br /><em>Pixel-level care.</em></h2>
              <p>I help teams build the system behind the screen, then make every screen feel effortless.</p>
            </div>
            <div className="capabilities-grid">
              {capabilities.map((item) => (
                <article key={item.number} className={`capability-card capability-card--${item.color}`} data-cursor>
                  <div className="capability-top"><span>{item.number}</span><i><Icon name={item.icon} /></i></div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <ul>
                    {item.tags.map((tag) => <li key={tag}>{tag}</li>)}
                  </ul>
                </article>
              ))}
            </div>
          </section>

          <section className="section work-section" id="work">
            <div className="section-heading section-heading--work" data-reveal>
              <div className="section-label"><span>03</span><p>Selected work</p></div>
              <h2>Platforms built for<br /><em>real-world complexity.</em></h2>
              <p>Architecture stories from marketplaces, AI-powered intelligence and lead-management products.</p>
            </div>

            <div className="projects-list">
              {projects.map((project) => (
                <article key={project.title} className={`project-card project-card--${project.theme}`}>
                  <div className="project-copy" data-reveal>
                    <div className="project-meta"><span>{project.index}</span><span>{project.years}</span></div>
                    <p className="project-kicker">{project.subtitle}</p>
                    <h3>{project.title}</h3>
                    <p className="project-description">{project.description}</p>
                    <div className="project-outcome">{project.outcome}</div>
                  </div>
                  <div className="project-visual"><ProjectVisual type={project.visual} /></div>
                </article>
              ))}
            </div>
          </section>

          <section className="principles" aria-label="Engineering principles">
            <div className="principles-pin">
              <div className="section-label section-label--light"><span>04</span><p>How I think</p></div>
              <div className="principle-stack">
                {principles.map((principle) => (
                  <article key={principle.number} className={`principle-card principle-card--${principle.color}`}>
                    <div className="principle-number">{principle.number}</div>
                    <p>{principle.eyebrow}</p>
                    <h2>{principle.title}</h2>
                    <div className="principle-bottom"><span>{principle.body}</span><i>✦</i></div>
                  </article>
                ))}
              </div>
            </div>
          </section>

          <section className="section journey-section" id="journey">
            <div className="journey-intro" data-reveal>
              <div className="section-label"><span>05</span><p>The journey</p></div>
              <h2>Eight years.<br />One evolving <em>craft.</em></h2>
              <p>Across frameworks and product domains, the constant has been building frontend foundations that help people move with confidence.</p>
              <div className="education-note">
                <span>Foundation</span>
                <strong>{profile.education}</strong>
                <small>{profile.educationYears}</small>
              </div>
            </div>
            <div className="experience-list">
              <div className="experience-line"><div className="experience-line-fill" /></div>
              {experience.map((item, index) => (
                <article key={`${item.time}-${item.company}`} className="experience-item">
                  <span className="experience-dot"><i>{index + 1}</i></span>
                  <div className="experience-time">{item.time}</div>
                  <div className="experience-copy">
                    <p>{item.company}</p>
                    <h3>{item.role}</h3>
                    <span>{item.note}</span>
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="human-section">
            <div className="human-card" data-reveal>
              <div className="human-sticker">Technology,<br />with heart <span>♥</span></div>
              <div className="human-copy">
                <div className="section-label"><span>06</span><p>Beyond delivery</p></div>
                <p className="overline">Volunteer web developer · Easytoask</p>
                <h2>Useful software can be a form of <em>care.</em></h2>
                <p>
                  During a time of urgent need, Dinesh helped create a volunteer network connecting people with oxygen cylinders, blood resources and nearby hospital information.
                </p>
              </div>
              <div className="human-orbit" aria-hidden="true"><span>HELP</span><i /><i /><i /></div>
            </div>
          </section>
        </main>

        <footer className="contact-section" id="contact">
          <div className="contact-top" data-reveal>
            <div className="section-label section-label--light"><span>07</span><p>Let’s connect</p></div>
            <p>Have a complex frontend challenge?</p>
            <h2>Let’s make the web<br /><em>feel lighter.</em></h2>
          </div>

          <div className="contact-actions" data-reveal>
            <a className="contact-email" href={`mailto:${profile.email}`}>
              <span>Drop me a note</span>
              <strong>{profile.email}</strong>
              <i><Icon name="arrow" /></i>
            </a>
            <div className="contact-links">
              <a href={profile.linkedin} target="_blank" rel="noreferrer">LinkedIn <Icon name="external" /></a>
              <a href={profile.website} target="_blank" rel="noreferrer">Personal site <Icon name="external" /></a>
            </div>
          </div>

          <div className="footer-bottom">
            <span>© {new Date().getFullYear()} Dinesh Kumar</span>
            <span>Designed with colour. Engineered with care.</span>
            <a href="#top">Back to top ↑</a>
          </div>
        </footer>
      </div>
    </div>
  )
}

export default App
