import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'

const TRAIL_COUNT = 9

export default function FluidReveal() {
  const canvasRef = useRef(null)
  const overlayRef = useRef(null)
  const hintRef = useRef(null)
  const dotRef = useRef(null)
  const blobRefs = useRef([])

  useEffect(() => {
    const finePointer = window.matchMedia('(pointer: fine)').matches
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const root = document.documentElement
    const canvas = canvasRef.current
    const overlay = overlayRef.current
    const hint = hintRef.current
    const announceLayoutReady = () => {
      window.dispatchEvent(new window.Event('portfolio:layout-ready'))
    }

    if (!finePointer || reducedMotion || !canvas || !overlay) {
      root.classList.remove('reveal-ready')
      root.classList.add('reveal-complete')
      if (overlay) overlay.style.display = 'none'
      const layoutFrame = window.requestAnimationFrame(announceLayoutReady)
      return () => window.cancelAnimationFrame(layoutFrame)
    }

    root.classList.add('reveal-ready')
    const context = canvas.getContext('2d')
    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 }
    const trail = Array.from({ length: TRAIL_COUNT }, () => ({ ...target }))
    let frameId
    let revealStarted = false
    let revealDone = false
    let autoTimer

    const sizeCanvas = () => {
      const dpr = Math.min(window.devicePixelRatio, 1.5)
      canvas.width = window.innerWidth * dpr
      canvas.height = window.innerHeight * dpr
      canvas.style.width = `${window.innerWidth}px`
      canvas.style.height = `${window.innerHeight}px`
      context.setTransform(dpr, 0, 0, dpr, 0, 0)
      context.globalCompositeOperation = 'source-over'
      context.fillStyle = '#7567ff'
      context.fillRect(0, 0, window.innerWidth, window.innerHeight)
    }

    const completeReveal = () => {
      if (revealDone) return
      revealDone = true
      gsap.to(overlay, {
        autoAlpha: 0,
        duration: 1.05,
        ease: 'power3.inOut',
        onComplete: () => {
          overlay.style.display = 'none'
          gsap.set('.site-shell', { clearProps: 'transform,filter' })
          root.classList.remove('reveal-ready')
          root.classList.add('reveal-complete')
          announceLayoutReady()
        },
      })
    }

    const startReveal = () => {
      if (revealStarted) return
      revealStarted = true
      window.clearTimeout(autoTimer)
      gsap.to('.site-shell', {
        scale: 1,
        filter: 'blur(0px) saturate(1)',
        duration: 1.45,
        ease: 'expo.out',
      })
      gsap.to(hint, { autoAlpha: 0, y: -8, duration: 0.35 })
      gsap.delayedCall(1.05, completeReveal)
    }

    const drawLiquidHole = (point, index) => {
      const radius = Math.max(28, 104 - index * 8)
      const gradient = context.createRadialGradient(
        point.x,
        point.y,
        radius * 0.16,
        point.x,
        point.y,
        radius,
      )
      gradient.addColorStop(0, 'rgba(0,0,0,0.98)')
      gradient.addColorStop(0.64, 'rgba(0,0,0,0.86)')
      gradient.addColorStop(1, 'rgba(0,0,0,0)')
      context.fillStyle = gradient
      context.beginPath()
      context.arc(point.x, point.y, radius, 0, Math.PI * 2)
      context.fill()
    }

    const animate = () => {
      trail.forEach((point, index) => {
        const destination = index === 0 ? target : trail[index - 1]
        const ease = 0.25 - index * 0.015
        point.x += (destination.x - point.x) * ease
        point.y += (destination.y - point.y) * ease
      })

      if (!revealDone) {
        context.globalCompositeOperation = 'destination-out'
        trail.forEach(drawLiquidHole)
      }

      blobRefs.current.forEach((blob, index) => {
        if (!blob) return
        const point = trail[Math.min(index + 1, trail.length - 1)]
        blob.style.transform = `translate3d(${point.x}px, ${point.y}px, 0) translate(-50%, -50%)`
      })
      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${target.x}px, ${target.y}px, 0) translate(-50%, -50%)`
      }

      frameId = requestAnimationFrame(animate)
    }

    const onPointerMove = (event) => {
      target.x = event.clientX
      target.y = event.clientY
      if (!revealStarted) startReveal()
    }

    const onPointerOver = (event) => {
      const interactive = event.target.closest('a, button, [data-cursor]')
      root.classList.toggle('cursor-active', Boolean(interactive))
    }

    const onPointerDown = () => {
      root.classList.add('cursor-down')
    }
    const onPointerUp = () => {
      root.classList.remove('cursor-down')
    }

    sizeCanvas()
    animate()
    autoTimer = window.setTimeout(startReveal, 2200)
    window.addEventListener('resize', sizeCanvas)
    window.addEventListener('pointermove', onPointerMove, { passive: true })
    document.addEventListener('pointerover', onPointerOver, { passive: true })
    document.addEventListener('pointerdown', onPointerDown, { passive: true })
    document.addEventListener('pointerup', onPointerUp, { passive: true })

    return () => {
      window.clearTimeout(autoTimer)
      cancelAnimationFrame(frameId)
      window.removeEventListener('resize', sizeCanvas)
      window.removeEventListener('pointermove', onPointerMove)
      document.removeEventListener('pointerover', onPointerOver)
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('pointerup', onPointerUp)
      root.classList.remove('reveal-ready', 'cursor-active', 'cursor-down')
    }
  }, [])

  return (
    <>
      <div ref={overlayRef} className="fluid-reveal" aria-hidden="true">
        <canvas ref={canvasRef} />
        <div ref={hintRef} className="reveal-hint">
          <span>Move to reveal</span>
          <svg viewBox="0 0 38 38" aria-hidden="true">
            <path d="M12 9 28 19 18 22 15 30 12 9Z" />
          </svg>
        </div>
      </div>
      <div className="fluid-cursor" aria-hidden="true">
        {[0, 1, 2, 3].map((item) => (
          <span
            key={item}
            ref={(node) => {
              blobRefs.current[item] = node
            }}
            className={`cursor-blob cursor-blob--${item + 1}`}
          />
        ))}
        <span ref={dotRef} className="cursor-dot" />
      </div>
    </>
  )
}
