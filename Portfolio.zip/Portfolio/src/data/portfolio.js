export const profile = {
  name: 'Dinesh Kumar',
  shortName: 'DK',
  role: 'Frontend Engineer Architect',
  experience: '8 years',
  location: 'New Delhi, India',
  company: 'Nagarro',
  email: 'dineshkumarrrr@gmail.com',
  linkedin: 'https://www.linkedin.com/in/iamdineshkumar/',
  website: 'https://dineshonweb.com/',
  education: 'B.Tech, Computer Science — University of Delhi',
  educationYears: '2013 — 2017',
}

export const stack = [
  'React',
  'TypeScript',
  'Next.js',
  'Vue.js',
  'Angular',
  'NestJS',
  'D3.js',
  'Liferay',
]

export const capabilities = [
  {
    number: '01',
    icon: 'nodes',
    title: 'Frontend architecture',
    description:
      'Scalable boundaries, micro-frontends, BFFs and pragmatic technical direction for products built to evolve.',
    tags: ['Micro-frontends', 'SSR / SSG', 'BFF'],
    color: 'coral',
  },
  {
    number: '02',
    icon: 'spark',
    title: 'Product performance',
    description:
      'Fast rendering, intentional loading strategies, accessible interaction and SEO that starts in the architecture.',
    tags: ['Core Web Vitals', 'WCAG', 'SEO'],
    color: 'mango',
  },
  {
    number: '03',
    icon: 'blocks',
    title: 'Design systems',
    description:
      'Durable UI primitives and patterns that keep multiple teams shipping with one coherent product language.',
    tags: ['Tokens', 'Components', 'DX'],
    color: 'aqua',
  },
  {
    number: '04',
    icon: 'people',
    title: 'Engineering leadership',
    description:
      'Architecture decisions made legible through standards, mentorship and close collaboration across disciplines.',
    tags: ['Mentoring', 'Standards', 'Delivery'],
    color: 'violet',
  },
]

export const projects = [
  {
    index: '01',
    years: '2025 — 2026',
    title: 'JSW One MSME',
    subtitle: 'B2B marketplace architecture',
    description:
      'Led a React micro-frontend mobile architecture with reusable standards, enterprise dashboards, search experiences and NestJS backend-for-frontend services.',
    outcome: 'Architecture · React · NestJS · SSR/SSG',
    theme: 'purple',
    visual: 'marketplace',
  },
  {
    index: '02',
    years: '2024 — 2025',
    title: 'Aviso AI',
    subtitle: 'Revenue intelligence platform',
    description:
      'Built within a predictive product ecosystem spanning forecasting, pipeline management, deal guidance, AI agents and conversational intelligence.',
    outcome: 'Vue.js · D3.js · Real-time data',
    theme: 'yellow',
    visual: 'intelligence',
  },
  {
    index: '03',
    years: '2020 — 2024',
    title: 'Thryv Leads Platform',
    subtitle: 'Lead management at scale',
    description:
      'Shaped client-facing lead management and conversion experiences for the Yellowpages, Superpages and Dexknows product ecosystem.',
    outcome: 'Angular · Highcharts · Liferay · React',
    theme: 'teal',
    visual: 'leads',
  },
]

export const principles = [
  {
    number: '01 / 03',
    eyebrow: 'Architecture principle',
    title: 'Build primitives, not patches.',
    body: 'The strongest frontend systems make the next feature easier—not merely the current feature possible.',
    color: 'coral',
  },
  {
    number: '02 / 03',
    eyebrow: 'Product principle',
    title: 'Performance is part of the experience.',
    body: 'Speed, accessibility and clarity belong in the product conversation from the first architectural decision.',
    color: 'mango',
  },
  {
    number: '03 / 03',
    eyebrow: 'Team principle',
    title: 'Make decisions easy to understand.',
    body: 'Good architecture gives teams clear boundaries, useful defaults and room to do their best work.',
    color: 'aqua',
  },
]

export const experience = [
  {
    time: 'Now',
    role: 'Frontend engineering & architecture',
    company: 'Nagarro',
    note: 'Building scalable product platforms and guiding frontend architecture.',
  },
  {
    time: '2024 — 2025',
    role: 'Revenue intelligence',
    company: 'Aviso AI',
    note: 'Modern product architecture for high-density, real-time data experiences.',
  },
  {
    time: '2020 — 2024',
    role: 'Lead-management platforms',
    company: 'Thryv ecosystem',
    note: 'Frontend platforms spanning Angular, React, Liferay and data visualization.',
  },
  {
    time: '2017 →',
    role: 'The first production pixel',
    company: 'Frontend journey',
    note: 'Eight years of turning complex product needs into calm, usable systems.',
  },
]
